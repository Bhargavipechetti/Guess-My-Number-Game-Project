let secretNumber = Math.floor(Math.random() * 20) + 1;
let score = 20;
let highScore = 0;
console.log(secretNumber);

//selecting the check button
//add event listener to check button

const c = document.querySelector(".check");
c.addEventListener("click", () => {
  //fetch the user input from the DOM

  let guess = Number(document.querySelector(".guess").value);
  //console.log(guess)

  if (!guess) {
    alert("Enter a valid value!");
  }

  //correct guess
  else if (secretNumber === guess) {
    //change background color
    document.querySelector("body").style.backgroundColor = "#60b347";

    //dispaly message as below
    document.querySelector(".message").innerHTML = "You guessed it right!";
    // dispaly secret number
    document.querySelector(".number").textContent = secretNumber;

    //check for new highscore and display it
    document.querySelector(".highscore").innerHTML = score;
    document.querySelector(".btn check").style.backgroundColor = "#60b347";
  } else if (secretNumber > guess) {
    if (score > 0) {
      //dispaly you lost if score goes below 0
      score = score - 1;
      document.querySelector(".score").textContent = score;
      document.querySelector(".message").innerHTML = "Too Low!";
    } else {
      document.querySelector(".message").innerHTML = "You lost!";
      document.querySelector(".body").style.backgroundColor = "rgb(183,94,94)";
      document.querySelector("h1").textContent = "Answer is:";
      document.querySelector(".number").textContent = secretNumber;
    }
  } else if (secretNumber < guess) {
    if (score > 0) {
      score = score - 1;
      document.querySelector(".score").textContent = score;
      document.querySelector(".message").innerHTML = "Too High!";
    } else {
      document.querySelector(".message").innerHTML = "You lost!";
      document.querySelector(".body").style.backgroundColor = "rgb(183,94,94)";
      document.querySelector("h1").textContent = "Answer is:";
      document.querySelector(".number").textContent = secretNumber;
    }
  }
});
